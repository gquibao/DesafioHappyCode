﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Personagem : MonoBehaviour
{
    public static Personagem instance;

    private void Awake()
    {
        instance = this;
    }

    public void movimentar(GameManager.ACAO acao)
    {
        int x = 0;
        int y = 0;

        switch(acao)
        {
            case GameManager.ACAO.CIMA:
                y = 1;
                break;

            case GameManager.ACAO.BAIXO:
                y = -1;
                break;

            case GameManager.ACAO.ESQUERDA:
                x = -1;
                break;

            case GameManager.ACAO.DIREITA:
                x = 1;
                break;
        }

        transform.position = new Vector2(transform.position.x + x, transform.position.y + y);
    }
}
